import React from "react";
import "../styles/AboutLanding.css";
export default function Landing(): JSX.Element {
  return (
    <div className="landing">
      <h1 className="overlay_text">About Us</h1>
    </div>
  );
}
