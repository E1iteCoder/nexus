import React from "react";

export default function Profile() {
  return (
    <div>
      <h1> Welcome to your Profile page! </h1>
    </div>
  );
}
