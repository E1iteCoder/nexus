import React from "react";
import "../styles/Login.css";

type Props = {
  onFormSwitch: (formName: string) => void;
};

export default function Register(props: Props): JSX.Element {
  return (
    <div className="register-container">
      <div className="register-form">
        <div className="text-center mb-5">
          <img
            className="logo"
            src={"/pictures/logo.png"}
            alt="NexusRead logo"
          />
          <h2 className="title">Create your account</h2>
        </div>
        <form>
          <div className="input-group">
            <label htmlFor="email" className="label">Email address</label>
            <input
              type="email"
              className="input-field"
              id="email"
              placeholder="name@example.com"
            />
          </div>
          <div className="input-group">
            <label htmlFor="password" className="label">Password</label>
            <input
              type="password"
              className="input-field"
              id="password"
              placeholder="********"
            />
          </div>
          <button type="submit" className="submit-btn">
            Create account
          </button>
        </form>
        <div className="text-center mt-3">
          <p className="footer-text">
            Already have an account?{" "}
            <button
              type="button"
              className="login-link"
              onClick={() => props.onFormSwitch("SignIn")}
            >
              Login to your account
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
