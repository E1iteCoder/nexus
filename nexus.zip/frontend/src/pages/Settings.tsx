import React from "react";

export default function Settings() {
  return (
    <div>
      <h1> Welcome to your settings page!</h1>
    </div>
  );
}
